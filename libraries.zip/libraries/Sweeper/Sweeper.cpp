/*
 Sweeper.cpp - Interrupt driven library for Arduino to sweep servos with programmed position and timing
 Copyright (c) 2021 James K. Larson.  All rights reserved.

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#if defined(ARDUINO_ARCH_AVR)

#include <avr/interrupt.h>
#include <Arduino.h>
#include "Servo.h"
//#include <elapsedMillis.h>

#include "Sweeper.h"


static sweeper_t sweepers[MAX_SWEEPERS];                         // static array of sweeper structures
static bool  sweepersInitialized = false;			// if structures are initialized then can start interrupts
//static elapsedMillis millisTime = 0;				// has time since start of sketch.
//static volatile int8_t Channel[_Nbr_16timers ];             // counter for the servo being pulsed for each timer (or -1 if refresh interval)

uint8_t SweeperCount = 0;                                  // the total number of attached sweepers  


/************ static functions common to all instances ***********************/

static inline void handle_interrupt()
{
  unsigned long currentMillis = millis();			// TODO: use an elapsedMillis here?? - Not needed!
  //unsigned long currentMillis = millisTime;
  for (int i=0; i < SweeperCount; i++){
    if (!sweepers[i].allDone) {
      if ((currentMillis - sweepers[i].lastUpdate) > sweepers[i].updateInterval){      // time to update
        sweepers[i].lastUpdate = currentMillis;
        sweepers[i].pos += sweepers[i].increment;
        sweepers[i].servo.write(sweepers[i].pos);
        if (sweepers[i].increment > 0) {    // means we're increasing
          if (sweepers[i].pos >= sweepers[i].target) {
            sweepers[i].allDone = true;
            sweepers[i].oldPos = sweepers[i].pos;
          }
        }
        else {     // decreasing
          if (sweepers[i].pos <= sweepers[i].target) {
            sweepers[i].allDone = true;
            sweepers[i].oldPos = sweepers[i].pos;
          }
        }
      }
    }
  }
}

// Interrupt handlers for Arduino
// 
//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// Interrupt is called once a millisecond,
// Note that name of the ISR is "magic". There is no need to declare it separately.
//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
ISR(TIMER0_COMPA_vect)
{
  //digitalWrite(6,HIGH);		// can be used to check timing
  handle_interrupt();
  //digitalWrite(6,LOW);		// can be used to check timing
}

static void initISR()
{
  // Timer0 is already used for millis() - we'll just interrupt somewhere
  // in the middle.
  OCR0A = 0xAF;
  TIMSK0 |= _BV(OCIE0A);
}



/* Not sure anything like this is needed for Sweeper
static void finISR(timer16_Sequence_t timer)
{
    //disable use of the given timer
#if defined WIRING   // Wiring
  if(timer == _timer1) {
    #if defined(__AVR_ATmega1281__)||defined(__AVR_ATmega2561__)
    TIMSK1 &=  ~_BV(OCIE1A) ;  // disable timer 1 output compare interrupt
    #else
    TIMSK &=  ~_BV(OCIE1A) ;  // disable timer 1 output compare interrupt
    #endif
    timerDetach(TIMER1OUTCOMPAREA_INT);
  }

#else
  //For arduino - in future: call here to a currently undefined function to reset the timer
  (void) timer;  // squash "unused parameter 'timer' [-Wunused-parameter]" warning
#endif
}*/


/****************** end of static functions ******************************/

Sweeper::Sweeper()
{
  if( SweeperCount < MAX_SWEEPERS) {
    this->_sweeperIndex = SweeperCount++;                    // assign a sweeper index to this instance
        sweepers[this->_sweeperIndex].allDone = true;
	sweepers[this->_sweeperIndex].updateInterval = 10;   // store default values
	sweepers[this->_sweeperIndex].increment = 1;
	sweepers[this->_sweeperIndex].pos = 0;;
	sweepers[this->_sweeperIndex].oldPos = 0;
	
  }
  else
    this->_sweeperIndex = INVALID_SWEEPER ;  // too many swepers
}

uint8_t Sweeper::sweepAttach(int pin)
{
  if(this->_sweeperIndex < MAX_SWEEPERS ) {
    sweepers[this->_sweeperIndex].servo.attach(pin);
    // initialize the timer if it has not already been initialized
    if(sweepersInitialized == false){
      initISR();
      sweepersInitialized = true;
    }
  }
  return this->_sweeperIndex ;
}

void Sweeper::sweepDetach()
{
  sweepers[this->_sweeperIndex].servo.detach();
//  if(isTimerActive(timer) == false) {
//    finISR(timer);
//  }
}

// This must be protected from interrupts!!
uint8_t Sweeper::setTarget(int newTarget, int deltaTime)    // newTarget in degrees; deltaTime in milliseconds
{
  int sIndx = this->_sweeperIndex;
  int newIncrement = sweepers[sIndx].increment;		// get old values in case newTarget = oldPos
  int newIntrvl = sweepers[sIndx].updateInterval;
  if ((newTarget <= 180) && (newTarget >= 0)) {
    int moveReq = sweepers[sIndx].oldPos - newTarget;
    int aMoveReq = abs(moveReq);
    if (moveReq != 0) {		// if equal to zero, means no movement
      if ((aMoveReq / deltaTime) > 1) {
        newIncrement = aMoveReq / deltaTime;
        newIntrvl = 1;
      } else {
        newIncrement = 1;
        newIntrvl = deltaTime / aMoveReq;
      }
      if (moveReq > 0) {  // means a negative move
        newIncrement = -newIncrement;
      }
    }
    // do updates here - interrupt protected
    uint8_t oldSREG = SREG;
    cli();
    sweepers[sIndx].target = newTarget;
    sweepers[sIndx].increment = newIncrement;
    sweepers[sIndx].updateInterval = newIntrvl;
    SREG = oldSREG;
    return sIndx;
  } else {
    return 255;
  }
}

uint8_t Sweeper::setTargetGo(int newTarget, int deltaTime)    // newTarget in degrees; deltaTime in milliseconds
{
  uint8_t rVal = this->setTarget (newTarget, deltaTime);
  if (rVal != 255){
    this -> goNow();
  }
  return rVal;
}

void Sweeper::goNow () // along with setTarget, allows servos to be set up, then quickly triggered
{
  int sIndx = this->_sweeperIndex;
  sweepers[sIndx].allDone = false;		// should be atomic
}

bool Sweeper::sweepDone () // returns true if a programmed sweep is done; false if not
{
  int sIndx = this->_sweeperIndex;
  return sweepers[sIndx].allDone;		// should be atomic
}

void Sweeper::sweepReset()
{
  this -> resetTo(0);
}

void Sweeper::resetTo(int startPos)
{
  int sIndx = this->_sweeperIndex;
  sweepers[sIndx].allDone = true;
  sweepers[sIndx].pos = startPos;
  sweepers[sIndx].servo.write(startPos);
  sweepers[sIndx].oldPos = startPos;
  sweepers[sIndx].increment = abs(sweepers[sIndx].increment);
}

#endif // ARDUINO_ARCH_AVR

