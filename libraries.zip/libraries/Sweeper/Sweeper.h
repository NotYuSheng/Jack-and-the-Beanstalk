/*
  Sweeper.cpp - Interrupt driven library for Arduino to sweep servos with programmed position and timing.
  Copyright (c) 2021 James K. Larson.  All rights reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/* 
  A Sweeper is simply a servo with controlled movement. Desired position and 
  move time can be specified for each Sweeper. The millisecond timer (Timer0) is
  used to pulse each Sweeper appropriately once per millisecond. 
  Behind each Sweeper object is a Servo object.
  
  The methods are:

    Sweeper - Class for manipulating servo motors connected as Sweepers to Arduino pins.

    sweepAttach(pin)     - Create a Servo to be used as a Sweeper and attach it to a pin.
    sweepDetach()
    setTarget(newTarget, deltaTime)   -  newTarget in degrees; deltaTime in milliseconds - but wait for goNow to move.
    setTargetGo(newTarget, deltaTime) -  newTarget in degrees; deltaTime in milliseconds - move immediately.
    goNow ()     - along with setTarget, allows servos to be set up, then quickly triggered.
    sweepDone ()    - returns true if a programmed sweep is done; false if not
    sweepReset()       - move Sweeper to mid range (reset) position immediately.
    resetTo(startPos)     - Move the Sweeper immediately to startPos.

 */

#ifndef Sweeper_h
#define Sweeper_h

#include <inttypes.h>
#include "Servo.h"		

#define Sweeper_VERSION           1     // software version of this library

#define MAX_SWEEPERS   12
#define INVALID_SWEEPER         255     // flag indicating an invalid sweeper index

#if !defined(ARDUINO_ARCH_STM32F4)

// This structure is for the control array for the sweepers. Used by the interrupt service routine.
typedef struct {
    Servo servo;              // the servo controlled by this sweeper
    int  updateInterval;      // interval between updates
    volatile int pos;                  // current servo position
    volatile unsigned long lastUpdate; // last update of position
    volatile int increment;            // increment to move for each interval
    volatile int oldPos;
    volatile int target;
    volatile boolean allDone;
} sweeper_t;


class Sweeper
{
  public:
    Sweeper();
    uint8_t sweepAttach(int pin);
    void sweepDetach();
    uint8_t setTarget(int newTarget, int deltaTime);    // newTarget in degrees; deltaTime in milliseconds
    uint8_t setTargetGo(int newTarget, int deltaTime);    // newTarget in degrees; deltaTime in milliseconds
    void goNow (); // along with setTarget, allows servos to be set up, then quickly triggered
    bool sweepDone ();
    void sweepReset();
    void resetTo(int startPos);
//    void update(unsigned long currentMillis);
private:
   uint8_t _sweeperIndex;               // index into the channel data for this sweeper
};

#endif
#endif
